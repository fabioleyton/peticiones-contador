<?php
require 'db_config.php';

$tipo_pqr = $_POST['tipo_pqr'];
$nombre = $_POST['nombre'];
$documento = $_POST['documento'];
$correo = $_POST['correo'];

// Lógica de días restantes según el tipo de petición
switch ($tipo_pqr) {
    case 'denuncia':
    case 'derecho_peticion':
    case 'felicitacion':
    case 'queja':
    case 'reclamo':
    case 'sugerencia':
        $dias_habiles = 15;
        break;
    case 'peticion_consulta':
        $dias_habiles = 30;
        break;
    case 'peticion_documentos':
    case 'peticion_informacion':
    case 'peticion_entre_autoridades':
        $dias_habiles = 10;
        break;
    case 'peticion_por_congresistas':
        $dias_habiles = 5;
        break;
    default:
        $dias_habiles = 5;
        break;
}

// Fecha de inicio
$fecha_inicio = date('Y-m-d H:i:s');

// Calcular la fecha de expiración ajustada a días hábiles, considerando festivos
$fecha_expiracion = calcularDiasHabiles($fecha_inicio, $dias_habiles);

// Calcular tiempo restante en segundos (usando la fecha de expiración)
$fecha_inicio_timestamp = strtotime($fecha_inicio);
$fecha_expiracion_timestamp = strtotime($fecha_expiracion);
$tiempo_restante_segundos = $fecha_expiracion_timestamp - $fecha_inicio_timestamp;

// Insertar la nueva petición en la base de datos
$sql = "INSERT INTO peticiones (tipo, nombre, documento, correo, fecha_inicio, dias_restantes, tiempo_restante_segundos, estado, historial)
        VALUES ('$tipo_pqr', '$nombre', '$documento', '$correo', '$fecha_inicio', $dias_habiles, $tiempo_restante_segundos, 'activa', '')";

if ($conn->query($sql) === TRUE) {
    header('Location: index.php');
} else {
    echo "Error: " . $conn->error;
}
?>
